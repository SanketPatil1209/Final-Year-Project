from flask import Flask, render_template, request, redirect, url_for, send_file
from flask_mail import Mail, Message
import os
import joblib
import numpy as np

# TO load CSS
app = Flask(__name__, static_folder='static', static_url_path='/static')

# Load the pre-trained model
loaded_pipeline = joblib.load('pipeline.joblib')

# Configure Flask-Mail
app.config.update(
    DEBUG=True,
    # EMAIL SETTINGS
    MAIL_SERVER='smtp.gmail.com',
    MAIL_PORT=465,
    MAIL_USE_SSL=True,
    MAIL_USERNAME='heartgeeks1122@gmail.com',
    MAIL_PASSWORD='vuki vryd gxmp mwqf'
)
mail = Mail(app)

@app.route('/')
def root():
    return redirect(url_for('index'))

@app.route('/index')
def index():
    return render_template('index.html')

@app.route('/predict', methods=['POST'])
def predict():
    if request.method == 'POST':
        # Get the form data
        name = request.form['name']
        email = request.form['email']
        accuracy_class = request.form['accuracy_no']
        age = int(request.form['age'])
        sex = int(request.form['sex'])
        ct = int(request.form['ct'])
        trtbps = int(request.form['trtbps'])
        chol = int(request.form['chol'])
        fbs = int(request.form['fbs'])
        restecg = int(request.form['restecg'])
        thalachh = int(request.form['thalachh'])
        exng = int(request.form['exng'])
        oldpeak = float(request.form['oldpeak'])
        slp = int(request.form['slp'])
        caa = int(request.form['caa'])
        thall = int(request.form['thall'])

        # Make predictions
        input_values = np.array([age, sex, ct, trtbps, chol, fbs, restecg, thalachh, exng, oldpeak, slp, caa, thall]).reshape(1, -1)
        
        predictions = loaded_pipeline.predict(input_values)[0]
        predictions_1 = loaded_pipeline.predict(input_values)

        threshold = 0.5
        predicted_class_1 = 1 if predictions_1[0] >= threshold else 0

        if predicted_class_1 == 0:
            message = "You are Currently Healthy, but you have a chance of getting heart disease. Keep your lifestyle healthy."
        else:
            message = "Your Heart is unhealthy you may have heart disease. Please visit your nearest Doctor."

        # Create email message
        msg = Message("Heart Disease Prediction Results",
                      sender="heartgeeks1122@gmail.com",
                      recipients=[email])

        # HTML content of the email
        msg.html = f"""
        <html>
        <head>
          <style>
            body {{
              font-family: Arial, sans-serif;
              background-color: #f4f4f4;
              padding: 20px;
            }}
            .container {{
              max-width: 600px;
              margin: 0 auto;
              background-color: #000;
              padding: 20px;
              border-radius: 8px;
              box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            }}
            li {{
                list-style: none;
                font-size: 15px;
                margin-bottom: 5px;
            }}
            h1 {{
              color: #fff;
              font-weight: 700;

            }}
            p {{
              color: #fff;
              font-size: 16px;
            }}
            strong {{
                font-size: 16px;
                font-weight: 700;
            }}
            small{{
                font-size: 15px; 
                font-weight: 600;
                color: #FFC107;
            }}
            .message {{
                color: #FF0000;
                font-weight: 600;
            }}
            .footer-strong {{
                font-size: 16px;
                font-weight: 700;
            }}
            .footer {{
              font-size: 17px;
              background-color: #333;
              margin-top: 20px;
              padding: 20px;
              text-align: center;
              color: #fff;
            }}
          </style>
        </head>
        <body>
          <div class="container">
            <h1>Heart Attack Prediction Results👏</h1>
            <p>Dear <strong>{name}</strong>,</p>
            <p>Here are your heart Attack prediction results:</p>
            <ul>
              <li><small>Accuracy:</small> {accuracy_class}</li>
              <li><small>Prediction:</small> {predicted_class_1}</li>
            </ul>
            <p><strong>{name}</strong>, please find below the input values you provided:</p>
            <ul>
              <li><small>Age:</small> {age}</li>
              <li><small>Sex:</small> {sex}</li>
              <li><small>Cancer Stage:</small> {ct}</li>
              <li><small>Resting Blood Pressure:</small> {trtbps}</li>
              <li><small>Cholesterol:</small> {chol}</li>
              <li><small>Fasting Blood Sugar:</small> {fbs}</li>
              <li><small>Resting Electrocardiographic Results:</small> {restecg}</li>
              <li><small>Maximum Heart Rate Achieved:</small> {thalachh}</li>
              <li><small>Exercise Induced Angina:</small> {exng}</li>
              <li><small>ST Depression Induced by Exercise Relative to Rest:</small> {oldpeak}</li>
              <li><small>Slope of the Peak Exercise ST Segment:</small> {slp}</li>
              <li><small>Number of Major Vessels Colored by Fluoroscopy:</small> {caa}</li>
              <li><small>Thal:</small> {thall}</li>
            </ul>
            <p class="message">{message}</p>
            <div class="footer">
            <p class="footer-strong">Copyright &copy; 2024 Sent by Heart Geeks | Pune, Maharastra, India</p>
            <p>Privacy Policy | Terms of Use | visit www.heartattack.com</p>
            <p>contact@heartattack.com</p>
            <p>+91 88234 90233</p>
            </div>
          </div>
        </body>
        </html>
        """

        mail.send(msg)

        success_message = "Your prediction has been successfully sent via email."
        return render_template('result.html', prediction=predictions[0], prediction_1=predicted_class_1, message=message, name=name, email=email, age=age, sex=sex, ct=ct, trtbps=trtbps, chol=chol, fbs=fbs, restecg=restecg, thalachh=thalachh, exng=exng, oldpeak=oldpeak, slp=slp, caa=caa, thall=thall, success_message=success_message, accuracy_class=accuracy_class)

# To Get Report on Email
@app.route('/send-email', methods=['POST'])
def send_email():
    try:
        # Get Email and PDF
        pdf_file = request.files['pdf']
        customer_email = request.form['email']

        # Message for email
        msg = Message("Heart Disease Report",
                      sender="heartgeeks1122@gmail.com",
                      recipients=[customer_email])
        msg.body = "Please find the attached heart disease report."

        # PDF Attachment
        msg.attach("report.pdf", "application/pdf", pdf_file.read())

        # Send the email
        mail.send(msg)
        return 'Email sent successfully!', 200
    except Exception as e:
        return f'Error: {str(e)}', 500
    

# To Get Diet Plan on Email
@app.route('/send-diet-email', methods=['POST'])
def send_diet_email():
    try:
        # Get Email and PDF
        diet_pdf_file = request.files['pdf']
        patient_email = request.form['email']

        # Message for email
        msg = Message("Healthy Diet Plan for you",
                      sender="heartgeeks1122@gmail.com",
                      recipients=[patient_email])
        msg.body = "Please find the attached Diet Plan."

        # PDF Attachment
        msg.attach("diet.pdf", "application/pdf", diet_pdf_file.read())

        # Send the email
        mail.send(msg)
        
        # If the email is sent successfully, return a success response
        return 'Email sent successfully!', 200
    except Exception as e:
        # If there's an error, return an error response
        return f'Error: {str(e)}', 500


@app.route('/about-us')
def about_us():
    return render_template('about-us.html')

@app.route('/services')
def services():
    return render_template('services.html')

@app.route('/gallery')
def gallery():
    return render_template('gallery.html')

@app.route('/prediction')
def prediction():
    return render_template('prediction.html')

@app.route('/contact-us')
def contact_us():
    return render_template('contact-us.html')

if __name__ == '__main__':
    app.run(debug=True)