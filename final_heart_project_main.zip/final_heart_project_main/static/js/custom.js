function sendDiet() {
  // Loading SweetAlert Animation
  Swal.fire({
    title: "Sending Diet Plan",
    html: "Please wait...",
    allowOutsideClick: false,
    showConfirmButton: false,
    onBeforeOpen: () => {
      Swal.showLoading();
    },
  });

  // Get email
  const patientEmail = document.getElementById("email").innerText.trim();

  // Converting Content into PDF
  const element = document.querySelector(".diet_pdf_plan");
  html2pdf()
    .from(element)
    .toPdf()
    .get("pdf")
    .then(function (pdf) {
      var blob = pdf.output("blob");

      var formData = new FormData();
      formData.append("pdf", blob, "diet.pdf");
      formData.append("email", patientEmail);

      // To send email and pdf to python file
      fetch("/send-diet-email", {
        method: "POST",
        body: formData,
      })
        .then((response) => {
          Swal.close();

          if (response.ok) {
            // Success Sweetalert
            Swal.fire({
              icon: "success",
              title: "Report Sent!",
              text: "Your Diet Plan has been sent to your email.",
              timer: 3000, 
              showConfirmButton: true, // OK Button
            });
          } else {
            throw new Error("Failed to send email.");
          }
        })
        .catch((error) => {
          console.error("Error sending email:", error);
          // Error Sweetalert
          Swal.fire({
            icon: "error",
            title: "Oops...",
            text: "An error occurred while sending the Diet Plan. Please try again.",
            showConfirmButton: true,
          });
        });
    });
}
