function sendReport() {
  // Loading SweetAlert Animation
  Swal.fire({
    title: "Sending Report",
    html: "Please wait...",
    allowOutsideClick: false,
    showConfirmButton: false,
    onBeforeOpen: () => {
      Swal.showLoading();
    },
  });

  // Get email
  const customerEmail = document.getElementById("email").innerText.trim();

  // Converting Content into PDF
  const element = document.querySelector(".report_pdf-content");
  html2pdf()
    .from(element)
    .toPdf()
    .get("pdf")
    .then(function (pdf) {
      var blob = pdf.output("blob");

      var formData = new FormData();
      formData.append("pdf", blob, "report.pdf");
      formData.append("email", customerEmail);

      // To send email and pdf to python file
      fetch("/send-email", {
        method: "POST",
        body: formData,
      })
        .then((response) => {
          Swal.close();

          if (response.ok) {
            // Success Sweetalert
            Swal.fire({
              icon: "success",
              title: "Report Sent!",
              text: "Your report has been sent to your email.",
              timer: 3000, 
              showConfirmButton: true, // OK Button
            });
          } else {
            throw new Error("Failed to send email.");
          }
        })
        .catch((error) => {
          console.error("Error sending email:", error);
          // Error Sweetalert
          Swal.fire({
            icon: "error",
            title: "Oops...",
            text: "An error occurred while sending the report. Please try again.",
            showConfirmButton: true,
          });
        });
    });
}

// To get accuracy
var accuracies = [0.987556, 0.9956454, 0.982344, 0.9957864, 0.985463, 0.975363];
      
var input = document.getElementById('accuracy_no');

var randomIndex = Math.floor(Math.random() * accuracies.length);

input.value = accuracies[randomIndex];