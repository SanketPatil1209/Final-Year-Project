// To move cursor autometically on next input tag
const inputs = document.querySelectorAll('input');

inputs.forEach((input, index) => {
  input.addEventListener('keydown', function(event) {
    if (event.key === 'ArrowDown' || event.key === 'ArrowRight') {
      event.preventDefault();
      if (index < inputs.length - 1) {
        inputs[index + 1].focus();
      }
    } else if (event.key === 'ArrowUp' || event.key === 'ArrowLeft') {
      event.preventDefault();
      if (index > 0) {
        inputs[index - 1].focus();
      }
    }
  });
});


// To Get Current Date
var currentDate = new Date();

// Extract the components of the date (day, month, year)
var day = ("0" + currentDate.getDate()).slice(-2);
var month = ("0" + (currentDate.getMonth() + 1)).slice(-2); 
var year = currentDate.getFullYear();

// Formatting the date in d-m-Y format
var formattedDate = day + "-" + month + "-" + year;

// Update the formatted date into the id
document.getElementById("current-date").textContent = formattedDate;

// Update the formatted date into the id
document.getElementById("current-diet-date").textContent = formattedDate;


// To download Report Plan
document.addEventListener("DOMContentLoaded", function () {
    var downloadButton = document.getElementById("download_report-btn");

    downloadButton.addEventListener("click", function () {
        var dietContentElement = document.querySelector(".report_pdf-content");

        var opt = {
            margin: 2,
            filename: "diet_plan.pdf",
            image: { type: "jpeg", quality: 0.98 },
            html2canvas: { scale: 2 },
            jsPDF: { unit: "mm", format: "a4", orientation: "portrait" },
        };

        html2pdf().from(dietContentElement).set(opt).save();
    });
});

// To download diet plan
document.addEventListener("DOMContentLoaded", function () {
    var downloadButton = document.getElementById("download-diet-plan");

    downloadButton.addEventListener("click", function () {
        var dietContentElement = document.querySelector(".diet_pdf_plan");

        var opt = {
            margin: 2,
            filename: "diet_plan.pdf",
            image: { type: "jpeg", quality: 0.98 },
            html2canvas: { scale: 2 },
            jsPDF: { unit: "mm", format: "a4", orientation: "portrait" },
        };

        html2pdf().from(dietContentElement).set(opt).save();
    });
});

// For Circular Animation
document.addEventListener('DOMContentLoaded', function() {
    let circularProgress = document.querySelector(".circular-progress"),
        progressValue = document.querySelector(".progress-value");

    // Parse the accuracy value
    let accuracyValue = parseFloat(progressValue.textContent.trim()); 

    // Convert accuracy to percentage
    let progressEndValue = accuracyValue * 100,
        speed = 70,
        progressStartValue = 0;
    
    let progress = setInterval(() => {
        if (progressStartValue < progressEndValue) {
            progressStartValue++;

            // Update progress text content and background
            progressValue.textContent = `${progressStartValue.toFixed(2)}%`;
            circularProgress.style.background = `conic-gradient(#ffbf00 ${progressStartValue * 3.6}deg, #ededed 0deg)`;
        } else {
            clearInterval(progress);
        }    
    }, speed);
});

// Number Counter Animation
const myNum = document.querySelectorAll('.count');
const speed = 100; // Adjust the speed for animation

myNum.forEach((myCount) => {
    let target_count = parseInt(myCount.dataset.count);
    let init_count = +myCount.innerText;
    
    let new_increment_num = Math.ceil(target_count / speed);
    
    const updateNumber = () => {
        init_count = Math.min(init_count + new_increment_num, target_count);
        myCount.innerText = init_count;

        if (init_count < target_count) {
            setTimeout(updateNumber, 50); // Adjust the delay for better performance
        }
    }

    updateNumber();
});


    // gallery isotope and filter
    var galleryIsotope = $('.gallery-container').isotope({
        itemSelector: '.gallery-item',
        layoutMode: 'fitRows'
    });
    $('#gallery-flters li').on('click', function () {
        $("#gallery-flters li").removeClass('active');
        $(this).addClass('active');

        galleryIsotope.isotope({filter: $(this).data('filter')});
    });


